#include <iostream>
#include <math.h>

#include "controller.hh"
#include "timestamp.hh"

using namespace std;


/* AIMD constants*/

const unsigned int ADD_INCREASE = 1.0;
const float MULT_DECREASE = 0.5;
const int MAX_WINDOW = 140;


/* Default constructor */
Controller::Controller( const bool debug )
  : debug_( debug )
  , window_size_ ( 1 )
  , timeout ( false )
  , congWins_before_timeout(0)
{}

/* Get current window size, in datagrams */
unsigned int Controller::window_size(void)
{
  unsigned int the_window_size = this->window_size_; 
  if ( debug_ ) {
    cerr << "\nAt time " << timestamp_ms()
	 << " window size is " << the_window_size << endl;
  }

  return floor(the_window_size);
}

/* A datagram was sent */
void Controller::datagram_was_sent( const uint64_t sequence_number,
				    /* of the sent datagram */
				    const uint64_t send_timestamp,
                                    /* in milliseconds */
				    const bool after_timeout
				    /* datagram was sent because of a timeout */ )
{
  /* Default: take no action */

  if ( debug_ ) {
    cerr << "\nAt time " << send_timestamp
	 << " sent datagram " << sequence_number << " (timeout = " << after_timeout << ")\n";
  }
  
  if (after_timeout){
	this->timeout = after_timeout;
        if (window_size_ > 2){
  	   this->congWins_before_timeout = window_size_ /2;
        }
        cerr << "\n 1. Ocorrencia de Time out at time " << send_timestamp
	 << " sent datagram " << sequence_number << " (timeout = " << this->timeout << ")\n";
  }
}

unsigned int rtt_threshold = 50;

/* An ack was received */
void Controller::ack_received( const uint64_t sequence_number_acked,
			       /* what sequence number was acknowledged */
			       const uint64_t send_timestamp_acked,
			       /* when the acknowledged datagram was sent (sender's clock) */
			       const uint64_t recv_timestamp_acked,
			       /* when the acknowledged datagram was received (receiver's clock)*/
			       const uint64_t timestamp_ack_received )
                               /* when the ack was received (by sender) */
{
  float rtt = float(timestamp_ack_received - send_timestamp_acked);

  //if ( debug_ ) {
      cerr << "\n1.1 RTT is " << rtt << " while RTT threshold is " << rtt_threshold << endl;
      cerr << "\nWindow_size is " << this->window_size_ << endl;
  //}
  /* AIMD:*/



   cerr << "2. windows size is " << this->window_size_ << " rtt_threshold is "<< rtt_threshold << " Congwins_before_timeout is " << this->congWins_before_timeout << " Timeout is " << this->timeout << "\n" << endl;

   if (this->congWins_before_timeout > rtt_threshold ){
   	rtt_threshold = this->congWins_before_timeout; 
        cerr <<"3. NOVO congWins_before_timeout "<< this->congWins_before_timeout << endl;
   }
 /* Taxa de transmissão limitada pelo tamanho da janela de congestionamento*/
   if (this->window_size_ < rtt_threshold && !this->timeout) {
    cerr << "4. Slow Start, Crescimento exponencial\n" << endl;
	this->window_size_ += this->window_size_;
    cerr <<" 4.1. Novo window size is "<< this->window_size_ << endl;
  }else if (this->window_size_ < MAX_WINDOW && !this->timeout){
    cerr << "5. Slow Start fineshed. Crescimento passa a ser linear\n" << endl;
	this->window_size_ += ADD_INCREASE;
    cerr <<"5.1 Novo window size is "<< this->window_size_ << endl;
  } else  if (this->window_size_ >= MAX_WINDOW && !this->timeout){
        cerr << "6. Decrease windows size.\n" << endl;
        this->window_size_ =  this->window_size_*MULT_DECREASE;
  }else if (this->timeout){
        cerr << "8. Reiniciando windows size\n" << endl;
        //if ( debug_ ) {
           cerr << "8.1 Windows size is: " << this-> window_size_ << " Threshold metade da windows size: " << rtt_threshold << "\n" << endl;
	//}
	if (this->window_size_ > 2){
        	rtt_threshold =  this->window_size_*MULT_DECREASE;
	}
        this->window_size_ = 1;
        cerr <<"\n8. Novo window decrease is: "<< this->window_size_ << endl;
        this->timeout = 0;
  }

   		
  /* Default: take no action */

  if ( debug_ ) {
    cerr << "At time " << timestamp_ack_received
	 << "\n received ack for datagram " << sequence_number_acked
	 << "\n (send @ time " << send_timestamp_acked
	 << "\n, received @ time " << recv_timestamp_acked << " by receiver's clock)\n" << endl;
  }

}

/* How long to wait (in milliseconds) if there are no acks
   before sending one more datagram */
unsigned int Controller::timeout_ms(void)
{
  return 1000; /* timeout of one second */
}
